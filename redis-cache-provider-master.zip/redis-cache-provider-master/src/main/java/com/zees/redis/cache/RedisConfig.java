package com.zees.redis.cache;

import java.time.Duration;

import org.springframework.boot.autoconfigure.cache.RedisCacheManagerBuilderCustomizer;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCacheManager.RedisCacheManagerBuilder;
import org.springframework.data.redis.connection.RedisConnectionFactory;

@Configuration
public class RedisConfig {
// extends CachingConfigurerSuppor
//    @Value("${spring.data.redis.host}")
//    private String redisHost;
//
//    @Value("${spring.data.redis.port}")
//    private int redisPort;
//
//    @Value("${spring.cache.redis.time-to-live}")
//    private Long expireTime;



//    @Bean
//    public LettuceConnectionFactory lettuceConnectionFactory() {
//
//
//        LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory();
//        lettuceConnectionFactory.setHostName(this.redisHost);
//        lettuceConnectionFactory.setPort(this.redisPort);
//
//        return lettuceConnectionFactory;
//    }

//
//     @Bean
//    public RedisTemplate redisTemplate(LettuceConnectionFactory lettuceConnectionFactory) {
//
//
//        RedisTemplate redisTemplate = new RedisTemplate();
//
//        redisTemplate.setKeySerializer(new StringRedisSerializer());
//
//
//        redisTemplate.setConnectionFactory(lettuceConnectionFactory);
//        return redisTemplate;
//    }


//
//    @Bean
//    public RedisCacheConfiguration cacheConfiguration() {
//
//
//        RedisCacheConfiguration cacheConfig = RedisCacheConfiguration.defaultCacheConfig()
//                .entryTtl(Duration.ofSeconds(expireTime))
//                .disableCachingNullValues()
//                .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()));
//        cacheConfig.usePrefix();
//
//
//        return cacheConfig;
//    }

//    @Bean
//    public RedisMappingContext keyValueMappingContext() {
//        return new RedisMappingContext(new MappingConfiguration(new IndexConfiguration(),
//        		new MyKeyspaceConfiguration()));
//    }
//
//    public static class MyKeyspaceConfiguration extends KeyspaceConfiguration {
//
//        @Override
//        protected Iterable<KeyspaceSettings> initialConfiguration() {
//            KeyspaceSettings keyspaceSettings = new KeyspaceSettings(Session.class, "session");
//            keyspaceSettings.setTimeToLive(60L);
//            return Collections.singleton(keyspaceSettings);
//        }
//    }
//	@Bean
//	public RedisCacheManager cacheManager(RedisConnectionFactory connectionFactor) {
//		RedisCacheConfiguration config= RedisCacheConfiguration.defaultCacheConfig()
//				.entryTtl(Duration.ofSeconds(20));
//		
//		return RedisCacheManager.builder(connectionFactor).cacheDefaults(config).build();
//		
//	}
	
	/*  @Bean
	    public CacheManager cacheManager(RedisConnectionFactory connectionFactory) {
	        return RedisCacheManagerBuilder
	            .fromConnectionFactory(connectionFactory)
	            .withCacheConfiguration("myCache",
	                RedisCacheConfiguration.defaultCacheConfig()
	                    .entryTtl(Duration.ofSeconds(20)) // TTL set to 10 minutes
	            )
	            .build();
	    }

	    @Bean
	    public RedisCacheManagerBuilderCustomizer redisCacheManagerBuilderCustomizer() {
	        return (builder) -> builder
	            .withCacheConfiguration("customCache",
	                RedisCacheConfiguration.defaultCacheConfig()
	                    .entryTtl(Duration.ofSeconds(10)) // TTL set to 5 minutes
	            );
	    }*/
}