package com.zees.redis.cache.repositoriesredis;

import com.zees.redis.cache.models.Product;
import com.zees.redis.cache.models.ProductRedis;

import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepositoryRedis extends CrudRepository<ProductRedis, Long> {
	ProductRedis findFirstById(Long id);
	//void setTTLForAllKeys(int ttlInSeconds);
}
