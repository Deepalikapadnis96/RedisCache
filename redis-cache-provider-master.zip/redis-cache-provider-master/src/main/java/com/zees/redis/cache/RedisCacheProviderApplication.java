package com.zees.redis.cache;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.zees.redis.cache.services.ProductServiceImpl;

@SpringBootApplication
@EnableCaching
@EnableRedisRepositories("com.zees.redis.cache.repositoriesredis")
public class RedisCacheProviderApplication {
	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	public static void main(String[] args) {
		SpringApplication.run(RedisCacheProviderApplication.class, args);
	}

/*	@Component
	public class KeyFlush {
		@Autowired
		RedisTemplate<String, String> redisTemplate;

		@Scheduled(initialDelay = 20000, fixedDelay = Long.MAX_VALUE)
		public void flushRedis() {
			redisTemplate.getConnectionFactory().getConnection().flushDb();
		}
	}*/
}
