package com.zees.redis.cache.repositories;

import com.zees.redis.cache.models.Product;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

//@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {
    Product findFirstById(Long id);
   /* default void setTTLForAllKeys(int ttlInSecond) {
    	RedisTemplate<String, Product> redisTemplate = new RedisTemplate<>();
    	//redisTemplate.setConnectionFactory(connectionFactory);
    	redisTemplate.afterPropertiesSet();
    	Map<String, Product> allEntities= getAllEntities(redisTemplate);
    	setTTLForEntities(allEntities,ttlInSecond,redisTemplate);
    }
    default Map<String, Product> getAllEntities(RedisTemplate<String, Product> redisTemplate){
    	return redisTemplate.opsForHash().entries("inredis");
    }
    default void setTTLForEntities(Map<String, Product>entities, int ttlInSecond,RedisTemplate<String, Product>redisTemplate)
    {
    	for(String key: entities.keySet()) {
    		redisTemplate.expire(key, ttlInSecond,TimeUnit.SECONDS);
    	}
    } */
}
