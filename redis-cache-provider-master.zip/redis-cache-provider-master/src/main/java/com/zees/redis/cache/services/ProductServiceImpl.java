package com.zees.redis.cache.services;

import com.zees.redis.cache.models.Product;
import com.zees.redis.cache.models.ProductRedis;
import com.zees.redis.cache.repositories.ProductRepository;
import com.zees.redis.cache.repositoriesredis.ProductRepositoryRedis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepository;
	@Autowired
	private RedisTemplate<String, String> redistemp;
	@Autowired
	ProductRepositoryRedis productRepositoryRedis;

	public void setValueTTL(String key,String value,long ttlSecond) {
		redistemp.opsForValue().set(key, value);
		redistemp.expire(key, ttlSecond,TimeUnit.SECONDS);
	}
	@Override
	public Product createProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(Product product) {
		if (!Objects.isNull(product) && product.getId() != null) {
			Product oldProduct = productRepository.findFirstById(product.getId());
			oldProduct.setId(product.getId());
			oldProduct.setName(product.getName());
			oldProduct.setCategory(product.getCategory());
			oldProduct.setPrice(product.getPrice());
			oldProduct.setQuantity(product.getQuantity());
			Product save = productRepository.save(oldProduct);
//        	ProductRedis productRedis = new ProductRedis();
//        	save = new Product(productRedis.getId(),productRedis.getName(),
//        			productRedis.getCategory(),productRedis.getPrice(),productRedis.getQuantity());
//        	productRepositoryRedis.save(productRedis);

		}
		return null;
	}

	//@Override
	@Cacheable(value = "tryingrediscache", key = "#id")
	public Product getProductById(Long id) {
		
		
		
			
			ProductRedis productRedis = new ProductRedis();
		
			Product findFirstById = productRepository.findFirstById(id);
			
			productRedis = productRepositoryRedis.findFirstById(id);

			if (productRedis != null) {
				//productRedis = productRepositoryRedis.findFirstById(id);
				findFirstById = new Product(productRedis.getId(), productRedis.getName(), productRedis.getCategory(),
						productRedis.getPrice(), productRedis.getQuantity());
				System.out.println("from redis >>" + findFirstById);
			} else {
				System.out.println("from database :: ");
				findFirstById = productRepository.findFirstById(id);
				ProductRedis productRedis2;
				
				// productRedis2.setExpiration(60L);
				productRedis2 = new ProductRedis(findFirstById.getId(), findFirstById.getName(),
						findFirstById.getCategory(), findFirstById.getPrice(), findFirstById.getQuantity());
				productRedis2.setName("redis data");
				this.productRepositoryRedis.save(productRedis2);

			}
			return findFirstById;
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> products = (List<Product>) productRepository.findAll();
		return products;
	}

	@Override
	public void deleteProduct(Long productId) {
		productRepository.deleteById(productId);
	}
}
