package com.zees.redis.cache.controllers;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.redis.core.TimeToLive;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zees.redis.cache.models.Product;
import com.zees.redis.cache.services.ProductService;
import com.zees.redis.cache.services.ProductServiceImpl;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/api/v1")
@Log4j2
public class ProductController {

	@Autowired
	ProductService productService;
	@Autowired ProductServiceImpl pro;

	@PostMapping(value = "/products/create")
	public ResponseEntity<Product> createProduct(@RequestBody Product product) {
		try {
			log.info("creating the products::{}" ,product);
			return ResponseEntity.ok(productService.createProduct(product));
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@PutMapping("/products/update")
	// @CachePut(cacheNames = "product", key = "#product.id")
	public Product updateProduct(@RequestBody Product product) {
		try {
			return productService.updateProduct(product);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@GetMapping("/products/{id}")
	//@CacheEvict(value = "tryingrediscache", allEntries = true)
	//@Scheduled(fixedRateString = "${spring.cache.redis.time-to-live}")
	//@TimeToLive(unit =TimeUnit.SECONDS)
	// @Cacheable(value = "product", key = "#id")
	public Product getProductById(@PathVariable Long id) {
		try {
			log.info("fetching the data using id::{}" ,id);
			return pro.getProductById(id);
			
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@GetMapping("/products")
	@CacheEvict(value = "products", allEntries = true)
	@Scheduled(fixedRateString = "${spring.cache.redis.time-to-live}")
	@TimeToLive(unit =TimeUnit.SECONDS)
	// @Cacheable(value = "product")
	public List<Product> getAllProducts() {
		try {
			return productService.getAllProducts();
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@DeleteMapping("/products/{id}")
	// @CacheEvict(cacheNames = "product", key = "#id", beforeInvocation = true)
	public void deleteProduct(@PathVariable Long id) {
		try {
			productService.deleteProduct(id);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
}
